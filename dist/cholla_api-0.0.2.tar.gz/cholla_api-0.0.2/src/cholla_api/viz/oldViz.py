'''
Collection of old plotting functions that are no longer in use, but may be
    helpful in the future, so I store them here
'''


'''
Collection of plotting functions
'''

def plot_pressure_1D(data, head, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    pressure = data["pressure"][:,0,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"
    
    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.plot(pressure)

    ax.yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax.set_xlim(0, head["dims"][0])
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Pressure")
    ax.set_title("Pressure")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()

    
def plot_density_1D(data, head, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    density = data["density"][:,0,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"
    
    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.plot(density)

    ax.yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax.set_xlim(0, head["dims"][0])
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Density")
    ax.set_title("Density")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
def plot_velocity_1D(data, head, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    vel = data["vel_x"][:,0,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"
    
    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.plot(vel)

    ax.yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax.set_xlim(0, head["dims"][0])
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Velocity")
    ax.set_title("Velocity")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()

def plot_pressure_2D(data, head, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    pressure = data["pressure"][:,:,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"

    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.imshow(pressure)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)

    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))

    ax.set_xlim(0, head["dims"][0] - 1)
    ax.set_ylim(0, head["dims"][1] - 1)


    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Y (cells)")
    ax.set_title("Pressure")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()

    
def plot_density_2D(data, head, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density = data["density"][:,:,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"
    
    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.imshow(density)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)

    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))

    ax.set_xlim(0, head["dims"][0] - 1)
    ax.set_ylim(0, head["dims"][1] - 1)
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Y (cells)")
    ax.set_title("Density")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
    
def plot_velx_2D(data, head, plt_fmt, plt_kwargs):

    clb_fmt = plt_fmt["colorbar_fmt"]

    vel_x = data["vel_x"][:,:,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"

    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.imshow(vel_x)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)

    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))

    ax.set_xlim(0, head["dims"][0] - 1)
    ax.set_ylim(0, head["dims"][1] - 1)
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Y (cells)")
    ax.set_title("Velocity - x")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()


def plot_vely_2D(data, head, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    vel_y = data["vel_y"][:,:,0].T
    time = head["t"][0]
    time_str = f"t = {time:.3f}"

    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.imshow(vel_y)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)

    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))

    ax.set_xlim(0, head["dims"][0] - 1)
    ax.set_ylim(0, head["dims"][1] - 1)
    
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Y (cells)")
    ax.set_title("Velocity - y")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()

def plot_vel_2D(data, head, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]
    
    vel = data["vel_mag"][:,:,0].T
    
    time = head["t"][0]
    time_str = f"t = {time:.3f}"

    fig, ax = plt.subplots(nrows=1, ncols=1)

    im = ax.imshow(vel)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)

    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))

    ax.set_xlim(0, head["dims"][0] - 1)
    ax.set_ylim(0, head["dims"][1] - 1)
    
    
    ax.set_xlabel("X (cells)")
    ax.set_ylabel("Y (cells)")
    ax.set_title("Velocity")
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
'''
Collection of plotting functions that compare values at different snapshots
'''

def plot_density_compare_1D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    density1 = data1["density"][:,0,0].T
    density2 = data2["density"][:,0,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0])
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))

    for i in range(2):
        ax[i].plot(density[i])

        ax[i].set_xlim(xlims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.3f}", fontsize=26)

        ax[i].yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax[0].set_ylabel("Density")
    
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
def plot_pressure_compare_1D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    pressure1 = data1["pressure"][:,0,0].T
    pressure2 = data2["pressure"][:,0,0].T
    pressures = [pressure1, pressure2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0])
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))

    for i in range(2):
        ax[i].plot(pressures[i])

        ax[i].set_xlim(xlims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.3f}", fontsize=26)

        ax[i].yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax[0].set_ylabel("Pressure")
    
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()

def plot_velocity_compare_1D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    yval_fmt = plt_fmt["yval_fmt"]
    
    vel1 = data1["vel_x"][:,0,0].T
    vel2 = data2["vel_x"][:,0,0].T
    vels = [vel1, vel2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0])
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))

    for i in range(2):
        ax[i].plot(vels[i])

        ax[i].set_xlim(xlims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.3f}", fontsize=26)

        ax[i].yaxis.set_major_formatter(ticker.FuncFormatter(yval_fmt))

    ax[0].set_ylabel("Velocity")
    
    plt.tight_layout()
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
    
def plot_density_compare_2D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density1 = data1["density"][:,:,0].T
    density2 = data2["density"][:,:,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0] - 1)
    ylims = (0, head1["dims"][1] - 1)
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))
    
    for i in range(2):
        im = ax[i].imshow(density[i])

        ax[i].set_xlim(xlims)
        ax[i].set_ylim(ylims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.4f}", fontsize=26)

    divider = make_axes_locatable(ax[1])
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))
    
    ax[1].get_yaxis().set_ticks([])
    
    ax[0].set_ylabel("Y (cells)")
    fig.suptitle("Density")
    plt.tight_layout()
    plt.subplots_adjust(top=1.2)
    
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
def plot_pressure_compare_2D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density1 = data1["pressure"][:,:,0].T
    density2 = data2["pressure"][:,:,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0] - 1)
    ylims = (0, head1["dims"][1] - 1)
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))
    
    for i in range(2):
        im = ax[i].imshow(density[i])

        ax[i].set_xlim(xlims)
        ax[i].set_ylim(ylims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.4f}", fontsize=26)

    divider = make_axes_locatable(ax[1])
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))
    
    ax[1].get_yaxis().set_ticks([])
    
    ax[0].set_ylabel("Y (cells)")
    fig.suptitle("Pressure")
    plt.tight_layout()
    plt.subplots_adjust(top=1.2)
    
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
def plot_velx_compare_2D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density1 = data1["vel_x"][:,:,0].T
    density2 = data2["vel_x"][:,:,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0] - 1)
    ylims = (0, head1["dims"][1] - 1)
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))
    
    for i in range(2):
        im = ax[i].imshow(density[i])

        ax[i].set_xlim(xlims)
        ax[i].set_ylim(ylims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.4f}", fontsize=26)

    divider = make_axes_locatable(ax[1])
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))
    
    ax[1].get_yaxis().set_ticks([])
    
    ax[0].set_ylabel("Y (cells)")
    fig.suptitle("Velocity (x)")
    plt.tight_layout()
    plt.subplots_adjust(top=1.2)
    
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()


def plot_vely_compare_2D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density1 = data1["vel_y"][:,:,0].T
    density2 = data2["vel_y"][:,:,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0] - 1)
    ylims = (0, head1["dims"][1] - 1)
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))
    
    for i in range(2):
        im = ax[i].imshow(density[i])

        ax[i].set_xlim(xlims)
        ax[i].set_ylim(ylims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.4f}", fontsize=26)

    divider = make_axes_locatable(ax[1])
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))
    
    ax[1].get_yaxis().set_ticks([])
    
    ax[0].set_ylabel("Y (cells)")
    fig.suptitle("Velocity (y)")
    plt.tight_layout()
    plt.subplots_adjust(top=1.2)
    
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
def plot_vel_compare_2D(data1, head1, data2, head2, plt_fmt, plt_kwargs):
    
    clb_fmt = plt_fmt["colorbar_fmt"]

    density1 = data1["vel_mag"][:,:,0].T
    density2 = data2["vel_mag"][:,:,0].T
    density = [density1, density2]
    
    t1 = head1["t"][0]
    t2 = head2["t"][0]
    all_t = [t1,t2]
    
    xlims = (0, head1["dims"][0] - 1)
    ylims = (0, head1["dims"][1] - 1)
    
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(12,8))
    
    for i in range(2):
        im = ax[i].imshow(density[i])

        ax[i].set_xlim(xlims)
        ax[i].set_ylim(ylims)

        ax[i].set_xlabel("X (cells)")
        ax[i].set_title(f"t = {all_t[i]:.4f}", fontsize=26)

    divider = make_axes_locatable(ax[1])
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical', format=ticker.FuncFormatter(clb_fmt))
    
    ax[1].get_yaxis().set_ticks([])
    
    ax[0].set_ylabel("Y (cells)")
    fig.suptitle("Velocity")
    plt.tight_layout()
    plt.subplots_adjust(top=1.2)
    
    if plt_kwargs.get("imgfout"):
        plt.savefig(plt_kwargs["imgfout"])
    if plt_kwargs.get("show"):
        plt.show()
    plt.close()
    
    
    
'''
Previously resided in ChollaViz class, moved to ChollaSnap
'''
def key_check(self, key, key_str=None, ch_snap_check=None):

    if key_str is None:
        key_str = key

    if ch_snap_check is None:
        ch_snap_check = self.ch_snap

    # check we have key value, if not, raise keyerr
    try:
        ch_snap_check.data[key]
    except KeyError:
        err_message = '-- Error --\n'
        err_message += f'Unable to plot {key_str} \n'
        err_message += f'Missing {key} in snapshot \n'
        print(err_message)
        raise